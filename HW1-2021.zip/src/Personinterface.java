public interface Personinterface {
    public String getName();
    public void setName(String name);
    public String getSurname();
    public void setSurname(String surname);
    public String getEmail();
    public void setEmail(String email);
    public String getSifre();
    public void setSifre(String sifre);

}
