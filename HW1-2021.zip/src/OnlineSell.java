public class OnlineSell {
    private String Tlfn;
    private String Adrss;
}
