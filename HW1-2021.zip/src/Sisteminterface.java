public interface Sisteminterface {
    public final int arraysize=40;
    public final int branchsize=4;
    public final int furnituressize=120;
    public final int officechairsz=35;
    public final int officedesksz=20;
    public final int meetingtablesz=40;
    public final int bookcasesz=12;
    public final int officecabinetsz=12;
}
